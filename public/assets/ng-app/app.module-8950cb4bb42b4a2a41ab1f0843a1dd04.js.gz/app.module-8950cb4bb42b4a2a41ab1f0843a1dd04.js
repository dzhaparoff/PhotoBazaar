(function() { 'use strict';
	angular
	.module('phb', ['ngProgress']);
})();
