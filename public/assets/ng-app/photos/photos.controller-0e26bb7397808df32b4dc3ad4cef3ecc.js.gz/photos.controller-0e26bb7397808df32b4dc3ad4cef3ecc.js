(function() { 'use strict';

	angular
	.module('phb')
	.controller('photosController', photosController);

  photosController.$inject = ['$scope', '$location', '$http', '$compile']

	function photosController($scope, $location, $http, $compile){

	

	}

})();
