(function() { 'use strict';

	angular
	.module('phb')
	.controller('photosController', photosController);


	function photosController($scope, $location, $http, $compile){

	

	}

})();
