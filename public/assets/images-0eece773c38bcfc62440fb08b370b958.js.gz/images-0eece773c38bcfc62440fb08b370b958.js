(function() {
  $(function() {
    return $('a').fancybox({
      padding: 0
    });
  });

}).call(this);
